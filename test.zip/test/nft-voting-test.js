const { assert, expect } = require('chai');
const { ethers, waffle } = require("hardhat");
// const { isCallTrace } = require('hardhat/internal/hardhat-network/stack-traces/message-trace');
const {
    deployNft,
    mintNftToken,
    deployVoting,
} = require('./Cat-helpers');
require('@nomiclabs/hardhat-waffle');

const NFT_TOKEN_METADATA_URI = process.env.NFT_TOKEN_METADATA_URI;



describe('NFTVoting', async() => {
    let voting;
    let nftContract;

    before(async() => {
        deployer = await ethers.provider.getSigner(0);
        member1 = await ethers.provider.getSigner(1);
        member2 = await ethers.provider.getSigner(2);
        admin1 = await ethers.provider.getSigner(3);
        // console.log(await admin1.getAddress());
        admin2 = await ethers.provider.getSigner(4);
        // console.log(await admin2.getAddress());
        nonmember = await ethers.provider.getSigner(5);
        addToAdmins = await ethers.provider.getSigner(6);
        targetaddress = await ethers.provider.getSigner(7);
        const addToAdminsAddr = await addToAdmins.getAddress();
        // console.log(addToAdminsAddr);

        nftContract = await deployNft();
        const Voting = await ethers.getContractFactory("NFTVoting");
        voting = await Voting.deploy([await admin1.getAddress(), await admin2.getAddress()], nftContract.address);
        await voting.deployed();

        const nftMinted1 = await mintNftToken(
            nftContract,
            NFT_TOKEN_METADATA_URI,
            await member1.getAddress()
        );

        const nftMinted2 = await mintNftToken(
            nftContract,
            NFT_TOKEN_METADATA_URI,
            await member1.getAddress()
        );

        const nftMinted3 = await mintNftToken(
            nftContract,
            NFT_TOKEN_METADATA_URI,
            await member2.getAddress()
        );

    });

    describe("Add admins", () => {
        it('should add a new admin into the DAO', async() => {
            await voting.connect(admin1).addAdmins(await addToAdmins.getAddress());
            // console.log(result);
            // console.log(await addToAdmins.getAddress());
            // console.log(await addToAdmins.getAddress());
            // const x = await addToAdmins.getAddress();
            // console.log(x);
            // console.log(typeof(x));
            // const outcome = voting.admins(x);
            // console.log(await outcome);
            expect(await voting.admins(addToAdmins.getAddress())).to.equal(true);
        });
    });

    describe('Receive ethers', () => {
        it('should receive ethers', async() => {
            const tx = await nonmember.sendTransaction({
                to: voting.address,
                value: ethers.utils.parseEther("6")
            });
            // console.log(tx);
            let votingBalance = await ethers.provider.getBalance(voting.address);
            // console.log(votingBalance);
            expect(votingBalance).to.equal("6000000000000000000");
        });
    });

    describe('NFT balance', () => {
        it('should check the NFT balance', async() => {
            let balance = await voting.checkBalance(await member1.getAddress());
            console.log(balance);
        })
    })


})